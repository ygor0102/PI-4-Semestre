/**
 *
 * @author Ygor Oliveira | Yasmim Candelária | Dalila Di Lazzáro | Jeferson Davi
 */
package Servlet.Produto;

import DAO.ProdutoDAO;
import Model.Produto;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ProdutoServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String nome = request.getParameter("nome");
        int avaliacao = Integer.parseInt(request.getParameter("avaliacao"));
        String descricao = request.getParameter("descricao");
        String status = "Ativo";
        double preco = Double.parseDouble(request.getParameter("preco"));
        int qtdEstoque = Integer.parseInt(request.getParameter("qtdEstoque"));
        
        Produto produto = new Produto(nome, avaliacao, descricao, status, preco, qtdEstoque);
        boolean ok = ProdutoDAO.cadastrarProduto(produto);
        
        // Passo 3: Redirecionar para sucesso.jsp
            if (ok) {
                System.out.println("Sucesso!");
                response.sendRedirect("../Protegido/Sucesso.jsp");
            } else {
                System.out.println("Falha!");
                response.sendRedirect("Erro.jsp");
            }
   
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            
         List<Produto> listaProdutos = ProdutoDAO.listaProdutos();
         request.setAttribute("listaProdutos", listaProdutos);
         request.getRequestDispatcher("/Protegido_Admin/ConsultaProduto.jsp").forward(request, response);
    }
    
}
