
package DAO;

import Model.Produto;
import Utils.GerenciarConexao;
import static Utils.Utils.popularProduto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ProdutoDAO {
    
     public static boolean cadastrarProduto(Produto produto) {
        boolean ok = true;
        try {
            Connection con = GerenciarConexao.getConexao();
            String query = "insert into produto(nome, avaliacao, descricao, status, preco, qtd_estoque) values (?,?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, produto.getNome());
            ps.setInt(2, produto.getAvaliacao());
            ps.setString(3, produto.getDescricao());
            ps.setString(4, produto.getStatus());
            ps.setDouble(5, produto.getPreco());
            ps.setInt(6, produto.getQtdEstoque());  
            ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
            ok = false;
        }
        return ok;
    }
     
     public static boolean atualizarProduto(Produto produto) {
       boolean ok = true;
       String query = "update produto set nome=?, avaliacao=?, descricao=?, status=?, preco=?, qtd_estoque=? where id_produto=?";
       Connection conn;
        try {
            conn = GerenciarConexao.getConexao();
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, produto.getNome());
            ps.setInt(2, produto.getAvaliacao());
            ps.setString(3, produto.getDescricao());
            ps.setString(4, produto.getStatus());
            ps.setDouble(5, produto.getPreco());
            ps.setInt(6, produto.getQtdEstoque());
            ps.setInt(7, produto.getIdProduto());

            ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
            ok = false;
        }
        return ok;
   }
     
     public static boolean atualizarStatus(String status, int idProduto) {
       boolean ok = true;
       String query = "update produto set status=? where id_produto=?";
       Connection conn;
        try {
            conn = GerenciarConexao.getConexao();
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, status);
            ps.setInt(2, idProduto);

            ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
            ok = false;
        }
        return ok;
   }
     
     public static Produto getProduto(int idProduto) {
       Produto produto = null;
       String query = "select * from produto where id_produto=?";
       Connection conn;
        try {
            conn = GerenciarConexao.getConexao();
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, idProduto);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                produto = popularProduto(rs);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return produto;
   }
     
     public static List<Produto> listaProdutos() {
        List<Produto> produtos = new ArrayList<>();
        String query = "select * from produto";
        Connection con;
        try {
            con = GerenciarConexao.getConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                int idProduto = rs.getInt("id_produto");
                String nome = rs.getString("nome");
                int avaliacao = rs.getInt("avaliacao");
                String descricao = rs.getString("descricao");
                String status = rs.getString("status");
                double preco = rs.getDouble("preco");
                int qtdEstoque = rs.getInt("qtd_estoque");
               
                Produto produto = new Produto(idProduto, nome, avaliacao, descricao, status, preco, qtdEstoque);
                produtos.add(produto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return produtos;   
    }
     
     public static List<Produto> listaProdutosNome(String nomeProduto) {
        List<Produto> produtos = new ArrayList<>();
        String query = "select * from produto where nome like ?";
        Connection con;
        try {
            con = GerenciarConexao.getConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, "%" + nomeProduto + "%");
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                int idProduto = rs.getInt("id_produto");
                String nome = rs.getString("nome");
                int avaliacao = rs.getInt("avaliacao");
                String descricao = rs.getString("descricao");
                String status = rs.getString("status");
                double preco = rs.getDouble("preco");
                int qtdEstoque = rs.getInt("qtd_estoque");
               
                Produto produto = new Produto(idProduto, nome, avaliacao, descricao, status, preco, qtdEstoque);
                produtos.add(produto);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return produtos;   
    }
}
